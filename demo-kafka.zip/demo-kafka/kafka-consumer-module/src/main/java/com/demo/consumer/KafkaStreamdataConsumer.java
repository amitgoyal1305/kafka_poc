package com.demo.consumer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaStreamdataConsumer {

    private final Logger logger = LoggerFactory.getLogger(KafkaStreamdataConsumer.class);

    @KafkaListener(topics = "wiki" , groupId = "wiki")
    public void consume(String message){
        logger.info(String.format("Recived message -> %s ",message));
    }
}
