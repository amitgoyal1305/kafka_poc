"# kafka_poc" 
