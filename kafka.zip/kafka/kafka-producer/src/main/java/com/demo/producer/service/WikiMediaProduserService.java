package com.demo.producer.service;

import com.launchdarkly.eventsource.EventHandler;
import com.launchdarkly.eventsource.EventSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.net.URI;
import java.util.concurrent.TimeUnit;

@Service
public class WikiMediaProduserService {

    private final Logger logger = LoggerFactory.getLogger(WikiMediaProduserService.class);
    private KafkaTemplate<String,String> kafkaTemplate;

    public WikiMediaProduserService(KafkaTemplate<String, String> kafkaTemplate) {
        this.kafkaTemplate = kafkaTemplate;
    }

    public void sendMessage() throws InterruptedException {
        logger.info("Called -> Producer Service for Event");
        String topic ="wiki";
        //to read real time data from wiki media, we use event source
        //String url = "http://localhost:8082/data";

        //https://stream.wikimedia.org/v2/stream/recentchange
        String url = "https://stream.wikimedia.org/v2/stream/recentchange";
        EventHandler eventHandler = new WikiMediaHandler(kafkaTemplate,topic);
        EventSource.Builder builder = new EventSource.Builder(eventHandler,URI.create(url));

        EventSource eventSource = builder.build();
        eventSource.start();
        logger.info("Event Called -> for wiki");
        /*OkHttpClient client = new OkHttpClient.Builder()
                .eventListener(eventHandler)
                .build();*/



       /* Request request = new Request.Builder()
                .url(server.url("/"))
                .build();*/
        TimeUnit.SECONDS.sleep(120);

    }
}
