package com.demo.demokafka.controller;

import com.demo.demokafka.model.User;
import com.demo.demokafka.produser.KafkaJsonProducer;
import com.demo.demokafka.produser.KafkaProducer;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
public class MessageController {

    @Autowired
    private KafkaProducer kafkaProducer;

    @Autowired
    private KafkaJsonProducer kafkaJsonProducer;

    @GetMapping("/send")
    public ResponseEntity<String> test(@RequestParam("message") String str){
        kafkaProducer.sendMessage(str);
        return ResponseEntity.ok("messages sent");
    }

    @PostMapping("/send")
    public ResponseEntity<String> payload(@RequestBody User user) throws Exception{
        kafkaJsonProducer.sendMessage(user);
        return ResponseEntity.ok(String.format("Message consume from topic : %s",user.toString()));
    }
}
